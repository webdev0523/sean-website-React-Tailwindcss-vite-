export { default as WhatIsWinlads } from "./what-is-winlads";
