export { default as Paradise } from "./paradise";
