export { default as HowToEnter } from "./how-to-enter";
