export { default as Hero } from "./hero";
