export { default as Faqs } from "./faqs";
