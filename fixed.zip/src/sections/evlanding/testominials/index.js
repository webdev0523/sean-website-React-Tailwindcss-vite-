export { default as Testominials } from "./testominials";
