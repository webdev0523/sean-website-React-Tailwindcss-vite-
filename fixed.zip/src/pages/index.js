export { default as GiveawayPage } from "./giveaway"
export { default as EVLandingPage } from "./evlanding"